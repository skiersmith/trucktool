using System;

namespace keepr.Models
{

    public class UserRecord
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public int RecordId { get; set; }
        
       

    }
}