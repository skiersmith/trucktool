using System;

namespace keepr.Models
{
    public class Transaction
    {
      
        public int Dot { get; set; }
        public string Notes { get; set; }
        public string Status { get; set; }
        public int UserId { get; set; }
         public int id { get; set; }




    }
}